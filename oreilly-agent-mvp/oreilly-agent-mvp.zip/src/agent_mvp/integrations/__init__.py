"""GitHub and external integrations."""
