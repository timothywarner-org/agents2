"""MCP server for O'Reilly Agent MVP."""

from .server import main

__all__ = ["main"]
