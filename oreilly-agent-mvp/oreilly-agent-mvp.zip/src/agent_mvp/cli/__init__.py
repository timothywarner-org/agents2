"""Interactive CLI for the agent MVP."""
