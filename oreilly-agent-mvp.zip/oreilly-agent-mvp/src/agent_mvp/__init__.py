"""
O'Reilly AI Agents MVP

Issue Triage + Implementation Draft Pipeline using LangGraph and CrewAI.
"""

__version__ = "0.1.0"
